
import {
    createBrowserRouter,
  } from "react-router-dom";
import Layout from '../layout/Layout';
import Login from '../pages/auth/login/Login';
import Register from '../pages/auth/register/Register';
import Home from '../pages/home/Home';

const Route = createBrowserRouter([
    {
        path:'/',
        element: <Layout/>,
        children:[
            {
                path:'/',
                element:<Home/>
            },
            {
                path:'/login',
                element:<Login/>
            },
            {
                path:'/register',
                element:<Register/>
            }
        ]
    }
])

export default Route;