import fluoride from '../../assets/images/fluoride.png'
import cavity from '../../assets/images/cavity.png'
import whitening from '../../assets/images/whitening.png'

export const ServiceData = [
    {
    id: 1,
    title:'Fluoride Treatment',
    dec: 'Lorem Ipsum is simply dummy printing and typesetting indust Ipsum has been the',
    image:fluoride,
},
{
    id: 2,
    title:'Cavity Filling',
    dec: 'Lorem Ipsum is simply dummy printing and typesetting indust Ipsum has been the',
    image:cavity,
}
,
{
    id: 3,
    title:'Teeth Whitening',
    dec: 'Lorem Ipsum is simply dummy printing and typesetting indust Ipsum has been the',
    image:whitening,
}
]