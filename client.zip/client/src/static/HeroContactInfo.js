import clock from '../../assets/icons/clock.svg';
import locationIcon from '../../assets/icons/marker.svg'
import phone from '../../assets/icons/phone.svg'


export const HeroContact = [
    {
        id:1,
        title: 'Opening Hours',
        dec:'Lorem Ipsum is simply dummy text of the pri',
        image:clock,
        bgColor: 'bg-gradient-to-r from-cyan-500 to-blue-500'
    },
    {
        id:2,
        title: 'Visit our locatio',
        dec:'Brooklyn, NY 10036, United States',
        image:locationIcon,
        bgColor: 'bg-[#3A4256]'
    }
    ,
    {
        id:3,
        title: 'Contact us now',
        dec:'+000 123 456789',
        image:phone,
        bgColor: 'bg-gradient-to-r from-cyan-500 to-blue-500'
    }
]