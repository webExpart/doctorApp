export const FooterInfo = [
    {
        id:1,
        title:'SERVICES',
        
    }
]