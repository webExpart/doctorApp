import people1  from '../../assets/images/people1.png'
import people2  from '../../assets/images/people2.png'
import people3  from '../../assets/images/people3.png'
export const TestimonialInfo =  [
    {
        id:1,
        title:'Winson Herry',
        address:'California',
        image:people1,
        review: 'It is a long established fact that by the readable content of a lot layout. The point of using Lorem a more-or-less normal distribu to using Content here, content',
    },
    {
        id:2,
        title:'Winson Herry',
        address:'California',
        image:people2,
        review: 'It is a long established fact that by the readable content of a lot layout. The point of using Lorem a more-or-less normal distribu to using Content here, content',
    },
    {
        id:3,
        title:'Winson Herry',
        address:'California',
        image:people3,
        review: 'It is a long established fact that by the readable content of a lot layout. The point of using Lorem a more-or-less normal distribu to using Content here, content',
    }
]