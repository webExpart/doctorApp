import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import {ResponsiveNav, DefualtNav}from  '../../style.js'
import { AiOutlineMenu, AiOutlineClose } from 'react-icons/ai';


const Navbar = () => {
  const [resNavActive, setresNavActive] =  useState(false);
  const resHandelClick = () =>{
    setresNavActive(prev=> !prev)
  }
  console.log(resNavActive)
  return (
    <div className={`w-full z-50 h-[64px] flex items-center justify-between p-5 sticky top-0 left-0 right-0 bg-white`}>
      <div className="logo">Doctors Portal</div>
      <nav className={`items-center justify-center gap-4 flex-col absolute top-[50px] md:right-[80px] right-[0px] bg-slate-400 p-5 w-full md:w-[200px] lg:flex-row lg:flex lg:bg-transparent  lg:w-[60%] lg:right-0 lg:top-0 lg:justify-end ${resNavActive ? "flex" : "hidden"}`}>
        <Link to="/" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>Home</Link>
        <Link to="/" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>About</Link>
        <Link to="/" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>Appointment</Link>
        <Link to="/" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>Reviews</Link>
        <Link to="/" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>Contact Us</Link>
        <Link to="/login" className='text-base hover:bg-[#3A4256] hover:text-[#ffffff] py-1 px-3 rounded-md ease-in-out duration-300'>Login</Link>
      </nav>
      <div className='lg:hidden md:flex items-center justify-center cursor-pointer' onClick={resHandelClick}>{resNavActive ? <AiOutlineClose/> : <AiOutlineMenu/> }</div>
    </div>
  )
}

export default Navbar