import React from 'react'

const Footer = () => {
  return (
    <div className='w-full flex flex-col bg-[url(assets/images/footer.png)] bg-center bg-cover'>
      <div className='w-full p-8 flex items-start justify-between flex-wrap md:flex-nowrap gap-4'> 
        <div className='flex flex-col gap-2 items-start w-full md:w-[320px]'>
          <h1 className='text-2xl font-semibold text-[#939393]'>SERVICES</h1>
          <span>Emergency Checkup</span>
          <span>Monthly Checkup</span>
          <span>Weekly Checkup</span>
          <span>Deep Checkup</span>
        </div>
        <div className='flex flex-col gap-2 items-start w-full md:w-[320px]'>
          <h1 className='text-2xl font-semibold text-[#939393]'>ORAL HEALTH</h1>
          <span>Fluoride Treatment</span>
          <span>Cavity Filling</span>
          <span>Teath Whitening</span>
          <span>Deep Checkup</span>
        </div>
        <div className='flex flex-col gap-2 items-start w-full md:w-[320px]'>
          <h1 className='text-2xl font-semibold text-[#939393]'>OUR ADDRESS</h1>
          <span>New York - 101010 Hudson</span>
        </div>
      </div>
      <div className='w-full text-center p-4'>All Copyright Reseved 2023</div>
    </div>
  )
}

export default Footer