import React from 'react'
import Appointment from './appointment/Appointment'
import Contact from './contact/Contact'
import Hero from './hero/Hero'
import Services from './services/Services'
import Testimonial from './testimonial/Testimonial'

const Home = () => {
  return (
    <div className='flex flex-col items-center gap-8'>
      <Hero/>
      <Services/>
      <Appointment/>
      <Testimonial/>
      <Contact/>
    </div>
  )
}

export default Home