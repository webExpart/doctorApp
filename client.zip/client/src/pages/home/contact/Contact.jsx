import React from 'react'
import Button from '../../../componentt/Button'

const Contact = () => {
  return (
    <div className='bg-[url(assets/images/appointment.png)] bg-center bg-cover flex w-full flex-col p-8 items-center gap-5'>
            <div className='flex flex-col items-center w-full'>
                <span className='text-[#19D3AE]'>Contact Us</span>
                <h1 className='text-white text-3xl font-semibold text-center'>Stay connected with us</h1>
            </div>
            <div className='flex flex-col  gap-4 w-full md:w-[500px]'>
                <input className='rounded p-1 outline-none' type="text" placeholder='Email Address'/>
                <input className='rounded p-1 outline-none' type="text" placeholder='Subject'/>
                <textarea className='rounded p-1 outline-none' rows="10" cols="50" placeholder='Your message'></textarea>
            </div>
            <Button text="send"/>
        
    </div>
  )
}

export default Contact