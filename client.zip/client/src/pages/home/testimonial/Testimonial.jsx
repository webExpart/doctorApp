import React from 'react'
import quote from '../../../../assets/icons/quote.svg'
import TestimonialCard from '../../../componentt/TestimonialCard'
import {TestimonialInfo} from '../../../static/TestimonialCardInfo.js'


const Testimonial = () => {
  return (
    <div className='w-full flex flex-col items-center gap-4'>
        <div className='flex justify-between p-5 items-center w-full'>
            <div>
                <span className='text-[#19D3AE]'>Appointment</span>
                <h1 className='text-[#3A4256] text-4xl font-semibold'>What Our Patients Says</h1>
            </div>
            <div className='w-[100px] h-[80px] md:w-[150px] md:h-[100px]'>
                <img className='w-full h-full' src={quote} alt="Image Not Found" />
            </div>
        </div>
        <div className='w-full p-4 flex flex-col flex-worp items-center gap-4 md:flex-row md:w-[80%] justify-between '>
            {
                TestimonialInfo.map((item)=>(
                    <TestimonialCard key={item.id} info={item}/>
                ))
            }
            
        </div>
    </div>
  )
}

export default Testimonial