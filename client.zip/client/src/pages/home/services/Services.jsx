import React from 'react'
import ServicesCard from '../../../componentt/ServicesCard'
import { ServiceData } from '../../../static/servicesData'
import treatment from '../../../../assets/images/treatment.png'
import Button from '../../../componentt/Button'

const Services = () => {
  return (
    <div className='flex flex-col gap-8 md:p-4 lg:p-5 p-2 items-center justify-start'>
        <div className='flex flex-col gap-1 md:p-4 lg:p-5 p-2 items-center justify-start'>
            <span className='font-bold text-[#19D3AE] text-xs'>OUR SERVICES</span>
            <h1 className='text-[#3A4256] text-[36px] text-center'>Services We Provide</h1>
        </div>
        <div className='w-full lg:p-[20px] md:p-[16px] flex flex-wrap gap-4 items-center justify-center'>
            {
                ServiceData.map((info)=>(
                    <ServicesCard key={info.id} info={info}/>
                ))
            }
            
        </div>
        <div className='flex items-center justify-center flex-col md:flex-row gap-8'>
            <div className='w-full md:w-[40%] md:h-[520px] h-[300px]'>
                <img className='w-full h-full object-cover md:object-contain' src={treatment} alt="" />
            </div>
            <div className='w-full md:w-[40%] flex flex-col gap-2'>
                <h3 className='text-2xl font-extrabold text-[#3A4256] '>Exceptional Dental <br/> Care, on Your Terms</h3>
                <span>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsumis that it has a more-or-less normal distribution of letters,as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page</span>
                <Button text="Get Start"/>
            </div>
        </div>
    </div>
  )
}

export default Services