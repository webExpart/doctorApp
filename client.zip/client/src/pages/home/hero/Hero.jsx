import React from 'react'
import Button from '../../../componentt/Button'
import HeroContactCard from '../../../componentt/HeroContactCard'
import {HeroContact} from '../../../static/HeroContactInfo.js'

const Hero = () => {
  return (
    <div className='min-h-full p-5 flex flex-col items-center gap-8'>
    <div className='flex items-center justify-center gap-8 flex-col-reverse lg:flex-row min-h-[70vh] w-full'>
        <div className='flex flex-col items-start lg:w-[655px] lg:h-[266]'>
            <h3 className='text-4xl font-bold text-[#3A4256]'>Your New Smile Starts<br/> Here</h3>
            <span className='text-[#3A4256] text-[16px]'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the</span>
            <Button text="Get Started"/>
        </div>
        <div className='lg:w-[594px] h-[355px]'>
            <img className='w-full h-full object-cover rounded-sm' src="assets/images/chair.png" alt="image not Found" />
        </div>
    </div>
    <div className='flex items-center justify-center gap-8 w-full p-3 flex-wrap md:w-[90%] m-[0 auto]'>
      {
        HeroContact.map((item)=>(
          <HeroContactCard key={item.id} info={item}/>
        ))
      }
      
    </div>
    </div>
  )
}

export default Hero