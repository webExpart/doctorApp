import React from 'react'
import doctorsmall from '../../../../assets/images/doctor-small.png'
import Button from '../../../componentt/Button'
import appointBg from '../../../../assets/images/appointment.png'

const Appointment = () => {
  return (
    <div className={`bg-[url(assets/images/appointment.png)] bg-center bg-cover flex items-center w-full md:h-[50vh] md:mt-24`}>
        <div className='hidden md:flex w-[45%] relative h-full justify-center'>
            <img className='absolute bottom-0 h-[120%]' src={doctorsmall} alt="Image Not Found" />
        </div>
        <div className='w-full md:w-[50%] flex flex-col p-4  gap-2'>
            <span className='text-[#19D3AE]'>Appointment</span>
            <h1 className='text-white text-4xl font-semibold'>Make an appointment Today</h1>
            <span className='text-white text-base '>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsumis that it has a more-or-less normal distribution of letters,as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page</span>
            <Button text='Get Started'/>
        </div>
    </div>
  )
}

export default Appointment