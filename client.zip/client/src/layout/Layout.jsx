import React from 'react'
import { Outlet } from 'react-router-dom'
import Footer from '../sharedComponent/footer/Footer'
import Navbar from '../sharedComponent/navbar/Navbar'

const Layout = () => {
  return (
    <div className='app'>
        <Navbar/>
        <Outlet/>
        <Footer/>
    </div>
  )
}

export default Layout