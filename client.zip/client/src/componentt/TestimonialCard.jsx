import React from 'react'

const TestimonialCard = ({info}) => {
  return (
    <div className='rounded shadow-md p-4 flex flex-col gap-4'>
       <div>
        <span>{info.review}</span>
       </div>
       <div>
        <div className='flex gap-2 items-center'>
            <img className='rounded-full border-4 border-solid border-[#19D3AE] w-[64px] h-[64px]' src={info.image} alt="" />
            <div className='flex gap-1 items-start flex-col'>
                <span className='font-bold text-xl text-[#3A4256]'>{info.title}</span>
                <span>{info.address}</span>
            </div>
        </div>
       </div>
    </div>
  )
}

export default TestimonialCard