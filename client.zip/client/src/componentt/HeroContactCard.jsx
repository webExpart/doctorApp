import React from 'react'

const HeroContactCard = ({info}) => {
  return (
    <div className={`${info.bgColor} md:w-[47%] lg:w-[350px] md:h-[120px] h-[100px] w-full  flex items-center justify-start p-4 rounded gap-2`}>
        <div className='w-[66px] h-[66px]'>
             <img className='w-full h-full object-content' src={info.image} alt="image not found" />
        </div>
        <div>
            <h3 className='text-lg text-white font-semibold font-sans'>{info.title}</h3>
            <span className='text-xs text-white'>{info.dec}</span>
        </div>
       
    </div>
  )
}

export default HeroContactCard