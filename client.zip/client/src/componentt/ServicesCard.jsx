import React from 'react'

const ServicesCard = ({info}) => {
  return (
    <div className='lg:w-[410px] lg:h-[310px] w-full h-auto md:w-[47%] flex flex-col gap-2 rounded shadow-md items-center justify-center'>
       <div className='md:w-[100px] md:h-[100px] w-[80px] h-[80px]'>
        <img className='w-full h-full object-contain' src={info.image} alt="Image Not found" />
       </div>
       <div className='w-full flex flex-col items-center p-2 text-center'>
        <h3>{info.title}</h3>
        <span>{info.dec}</span>
       </div>
    </div>
  )
}

export default ServicesCard