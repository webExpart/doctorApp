import React from 'react'

const Button = ({text}) => {
  return (
    <button className='bg-gradient-to-r w-[150px] from-cyan-500 to-blue-500 text-white font-semibold px-4 py-2 rounded-lg'>{text}</button>
  )
}

export default Button